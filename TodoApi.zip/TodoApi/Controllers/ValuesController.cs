﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace TodoApi.Controllers
{
    // 1A https://localhost:5001/api/values/row=a;column=2
    // 1B https://localhost:5001/api/values/v1x=0;v1y=0;v2x=0;v2y=10;v3x=10;v3y=10
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return "value";
        }


        // GET api/values/row=X;column=Y
        [HttpGet("row={row};column={column}")]
        public ActionResult<string> Get(string row, int column)
        {
            string returnValue = "Assumming A1 is (0,0) and F12 is (60, 60).  The vertices for ";
            returnValue += row;
            returnValue += column.ToString();
            returnValue += " are: ";

            // User has sent us the row and column.  We need to display the vertices
            // row must be A-F
            Regex r = new Regex("^[a-fA-F]*$");
            if (r.IsMatch(row)) 
            {
                // row is valid.  What about column? (1-12)
                if(column > 0 && column < 13)
                {
                    // Valid column.  Is it odd or even?
                    if(0 == column % 2)
                    {
                        returnValue += Even(row, column);
                    }
                    else
                    {
                        returnValue += Odd(row, column);
                    }
                }
                else
                {
                    // invalid column
                    returnValue = "column must be between 1-12: " + column.ToString() + " is not valid";
                }
            }  
            else
            {
                // invalid row
                returnValue = "row must be between a-f or A-F: " + row + " is not valid";
            }          

            return returnValue;
        }

        
        // C3:
        // https://localhost:5001/api/values/v1x=10;v1y=30;v2x=10;v2y=20;v3x=20;v3y=30
        // C4:
        // https://localhost:5001/api/values/v1x=20;v1y=20;v2x=10;v2y=20;v3x=20;v3y=30
        [HttpGet("v1x={v1x};v1y={v1y};v2x={v2x};v2y={v2y};v3x={v3x};v3y={v3y}")]
        public ActionResult<string> Get(int v1x, int v1y, int v2x, int v2y, int v3x, int v3y)
        {
            string returnValue = "Assumming A1 is (0,0) and F12 is (60, 60).  The row column is ";

            // If we're odd column then v1x == v2x
            if(v1x == v2x)
            {
                // row is v2y/10 0 = A, 1 = B, 2 = C, 3 = D, 4 = E, 5 = F
                // col is v3x/5
                returnValue += OddCol(v2y, v3x);
            }
            else
            {
                // row is v2y/10 0 = A, 1 = B, 2 = C, 3 = D, 4 = E, 5 = F
                // col is v1x/5
                returnValue += EvenCol(v2y, v1x);
            }


            return returnValue;
        }


        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        /*
         * Calculate the vertices based on even number column
         * string row - the row
         * int column - the column
         * return string - All vertices
         */
        private string Even(string row, int column)        
        {
            string returnValue = "(";
            int buffer = 0;
            // Convert the row to a number (in my thought A is 0, B is 1, etc...)
            int rowNumber = Int32.Parse(row, System.Globalization.NumberStyles.HexNumber) - 10;

            // (5 * col - 10, row * 10)   (5 * col, 10 * row)  (5 * col, (row + 1) * 10)
            // 1st item
            buffer = (5 * column) - 10;
            returnValue += buffer.ToString();
            returnValue += ", ";

            buffer = rowNumber * 10;
            returnValue += buffer.ToString();
            returnValue += ") (";

            // 2nd item
            // (5 * col, 10 * row)
            buffer = (5 * column);
            returnValue += buffer.ToString();
            returnValue += ", ";

            buffer = rowNumber * 10;
            returnValue += buffer.ToString();
            returnValue += ") (";

            // 3rd item
            // (5 * col, (row + 1) * 10)
            buffer = (5 * column);
            returnValue += buffer.ToString();
            returnValue += ", ";

            buffer = (rowNumber + 1) * 10;
            returnValue += buffer.ToString();
            returnValue += ")";

            return returnValue;
        }

        /*
         * Calculate the vertices based on odd number column
         * string row - the row
         * int column - the column
         * return string - All vertices
         */
        private string Odd(string row, int column)        
        {
            string returnValue = "(";
            int buffer = 0;
            // Convert the row to a number (in my thought A is 0, B is 1, etc...)
            int rowNumber = Int32.Parse(row, System.Globalization.NumberStyles.HexNumber) - 10;

            // (5 * col - 5, row * 10)   (5 * col - 5, (row + 1 ) * 10)  (5 * col + 5, (row + 1) * 10)
            // 1st item
            buffer = (5 * column) - 5;
            returnValue += buffer.ToString();
            returnValue += ", ";

            buffer = rowNumber * 10;
            returnValue += buffer.ToString();
            returnValue += ") (";

            // 2nd item
            // (5 * col - 5, (row + 1 ) * 10)
            buffer = (5 * column) - 5;
            returnValue += buffer.ToString();
            returnValue += ", ";

            buffer = (rowNumber + 1) * 10;
            returnValue += buffer.ToString();
            returnValue += ") (";

            // 3rd item
            // (5 * col + 5, (row + 1) * 10)
            buffer = (5 * column) + 5;
            returnValue += buffer.ToString();
            returnValue += ", ";

            buffer = (rowNumber + 1) * 10;
            returnValue += buffer.ToString();
            returnValue += ")";

            return returnValue;
        }

        /*
         * row is v2y/10 0 = A, 1 = B, 2 = C, 3 = D, 4 = E, 5 = F
         * col is v1x/5
         * int v2y 
         * int v1x
         * return string - row/column
         */
        private string EvenCol(int v2y, int v1x)
        {
            string returnValue = "";

            switch(v2y / 10)
            {
                case 0:

                    returnValue += "A";
                    break;

                case 1:

                    returnValue += "B";
                    break;

                case 2:

                    returnValue += "C";
                    break;

                case 3:

                    returnValue += "D";
                    break;

                case 4:

                    returnValue += "E";
                    break;

                case 5:

                    returnValue += "F";
                    break;

                default:

                    returnValue += "ERROR";
                    break;

            }

            returnValue += (v1x / 5).ToString();
            return returnValue;
        }

        /*
         * row is v2y/10 0 = A, 1 = B, 2 = C, 3 = D, 4 = E, 5 = F
         * col is v3x/5 - 1
         * int v2y 
         * int v3x
         * return string - row/column
         */
        private string OddCol(int v2y, int v3x)
        {
            string returnValue = "";

            switch(v2y / 10)
            {
                case 0:

                    returnValue += "A";
                    break;

                case 1:

                    returnValue += "B";
                    break;

                case 2:

                    returnValue += "C";
                    break;

                case 3:

                    returnValue += "D";
                    break;

                case 4:

                    returnValue += "E";
                    break;

                case 5:

                    returnValue += "F";
                    break;

                default:

                    returnValue += "ERROR";
                    break;

            }

            returnValue += ((v3x / 5) - 1).ToString();
            return returnValue;
        }
    }
}
